/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class TasksTest {
    
    public TasksTest() {
    }

    /**
     * Test of getTaskName method, of class Tasks.
     */
    @Test
    public void testGetTaskName() {
    }

    /**
     * Test of setTaskName method, of class Tasks.
     */
    @Test
    public void testSetTaskName() {
    }

    /**
     * Test of getTaskNumber method, of class Tasks.
     */
    @Test
    public void testGetTaskNumber() {
    }

    /**
     * Test of setTaskNumber method, of class Tasks.
     */
    @Test
    public void testSetTaskNumber() {
    }

    /**
     * Test of getTasDescription method, of class Tasks.
     */
    @Test
    public void testGetTasDescription() {
    }

    /**
     * Test of setTaskDescription method, of class Tasks.
     */
    @Test
    public void testSetTaskDescription() {
    }

    /**
     * Test of getDevDetails method, of class Tasks.
     */
    @Test
    public void testGetDevDetails() {
    }

    /**
     * Test of setDevDetails method, of class Tasks.
     */
    @Test
    public void testSetDevDetails() {
    }

    /**
     * Test of getTaskDuration method, of class Tasks.
     */
    @Test
    public void testGetTaskDuration() {
    }

    /**
     * Test of setTaskDuration method, of class Tasks.
     */
    @Test
    public void testSetTaskDuration() {
    }

    /**
     * Test of getTaskId method, of class Tasks.
     */
    @Test
    public void testGetTaskId() {
    }

    /**
     * Test of setTaskId method, of class Tasks.
     */
    @Test
    public void testSetTaskId() {
    }

    /**
     * Test of getTaskStatus method, of class Tasks.
     */
    @Test
    public void testGetTaskStatus() {
    }

    /**
     * Test of setTaskStatus method, of class Tasks.
     */
    @Test
    public void testSetTaskStatus() {
    }

    /**
     * Test of checkTaskDescription method, of class Tasks.
     */
    @Test
    public void testCheckTaskDescription() {
        
    }

    /**
     * Test of createTaskId method, of class Tasks.
     */
    @Test
    public void testCreateTaskId() {
    }

    /**
     * Test of printTaskDetails method, of class Tasks.
     */
    @Test
    public void testPrintTaskDetails() {
    }

    /**
     * Test of returnTotalHours method, of class Tasks.
     */
    @Test
    public void testReturnTotalHours() {
    }
    
}
